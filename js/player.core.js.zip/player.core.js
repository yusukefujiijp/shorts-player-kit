/*!
Project:  shorts-player-kit
File:     js/player.core.js
Role:     Player Core (DOM contract + perRoleAbs TTS + effects hook)
Policy:
  - Page-1 is Play-only (placeholder)
  - opening/transition/closing pages are pure effects (no text elements)
  - Content pages render a contracted DOM (.scene under #content)
  - TTS is per-role ABSOLUTE rate only (0.5–2.0, default 1.4); UI base rate hidden
  - Always fetch('./scenes.json') (no inline JSON)
Notes:
  - This build introduces: applyVersionToBody(scene), ensureSceneSurface(), and
    renderContent/renderEffect that emit contract DOM the CSS expects.
  - setText* helpers remain as thin adapters that write into the current .scene.
*/

(() => {
  'use strict';

  /* -----------------------------
   * Environment / Defaults
   * --------------------------- */
  const TTS_ENABLED = (typeof window.TTS_ENABLED === 'boolean') ? window.TTS_ENABLED : true;
  const speechFixes  = (window.speechFixes || {});
  window.__ttsFlags  = window.__ttsFlags || { readTag: true, readTitleKey: false, readTitle: true, readNarr: true };

  // Re-entrancy guard to prevent double-playing during transitions
  let __playingLock = false;

  /* -----------------------------
   * Backdrop layering (always at z=0)
   * --------------------------- */
  function ensureBgLayer() {
    let bg = document.getElementById('bgColor');
    if (!bg) {
      bg = document.createElement('div');
      bg.id = 'bgColor';
      document.body.insertBefore(bg, document.body.firstChild || null);
    }
    const s = bg.style;
    s.position = 'fixed';
    s.left = '0'; s.top = '0'; s.right = '0'; s.bottom = '0';
    s.zIndex = '0';
    s.pointerEvents = 'none';
    s.transition = s.transition || 'background-color 1.2s ease';
    s.transform = 'translateZ(0)';
    return bg;
  }

  function setBg(color) {
    try {
      if (!color) return;
      document.body.style.backgroundColor = color;
      const bg = ensureBgLayer();
      bg.style.backgroundColor = color;
    } catch(_) {}
  }

  function applyReadableTextColor(base, targetEl) {
    try {
      const m = /^#?([0-9a-f]{6})$/i.exec(String(base || '').trim());
      if (!m) return;
      const hex = m[1];
      const r = parseInt(hex.slice(0,2),16);
      const g = parseInt(hex.slice(2,4),16);
      const b = parseInt(hex.slice(4,6),16);
      const Y = 0.299*r + 0.587*g + 0.114*b; // luminance-ish
      const color = (Y < 140) ? '#ffffff' : '#111111';
      (targetEl || document.getElementById('content') || document.body).style.color = color;
    } catch(_) {}
  }

  /* -----------------------------
   * Version veil on <body>
   * --------------------------- */
  function applyVersionToBody(scene) {
    const v = (scene && (scene.version || scene.uiVersion)) || 'A';
    const body = document.body;
    body.classList.remove('version-A', 'version-B', 'version-T');
    if (v === 'B') body.classList.add('version-B');
    else if (v === 'T') body.classList.add('version-T');
    else body.classList.add('version-A');
  }

  /* -----------------------------
   * Scene Surface (contract DOM)
   * #content (positioned above bg, below debug panel)
   * --------------------------- */
  function ensureSceneSurface() {
    ensureBgLayer();
    let root = document.getElementById('content');
    if (!root) {
      root = document.createElement('div');
      root.id = 'content';
      // Keep above #bgColor but below debug-panel overlays
      root.style.position = 'relative';
      root.style.zIndex = '1';
      root.style.width = '100%';
      root.style.textAlign = 'center';
      document.body.appendChild(root);
    }
    // Flush previous scene (we create .scene anew each time)
    root.innerHTML = '';
    return root;
  }

  function createSceneShell() {
    const sceneEl = document.createElement('div');
    sceneEl.className = 'scene'; // CSS animates .scene in
    return sceneEl;
  }

  /* -----------------------------
   * Thin adapters (compat with older setText semantics)
   * They simply write into the current .scene in #content.
   * --------------------------- */
  function setTextInScene(sceneEl, selector, text) {
    let el = sceneEl.querySelector(selector);
    if (!el) {
      el = document.createElement('div');
      // normalize selector to className
      const cls = selector.replace(/^[.#]/,'');
      el.className = cls;
      sceneEl.appendChild(el);
    }
    el.textContent = String(text || '');
    if (selector === '.narr') el.style.whiteSpace = 'pre-line';
  }

  function setText(idOrKey, s) {
    // map legacy ids to contract classes
    const map = {
      'title_key': '.title_key',
      'titleKey':  '.title_key',
      'title':     '.title',
      'symbol':    '.symbol',   // inside the .symbol-bg band normally
      'narr':      '.narr'
    };
    const selector = map[idOrKey] || '.narr';
    const root = document.getElementById('content');
    if (!root) return;
    const sceneEl = root.querySelector('.scene') || root;
    setTextInScene(sceneEl, selector, s);
  }

  /* -----------------------------
   * Optional effect engine hook
   * --------------------------- */
  function runEffectIfAny(scene, anchorEl) {
    if (!scene || !scene.effect) return;
    if (!window.__effects || typeof __effects.run !== 'function') return;
    try {
      __effects.run(scene.effect, anchorEl || document.body, scene);
    } catch(_) {}
  }

  /* -----------------------------
   * TTS plumbing (perRole ABS)
   * --------------------------- */
  function getVoicesSafe() {
    try { return window.speechSynthesis.getVoices() || []; }
    catch (_) { return []; }
  }

  let jpVoice = null;
  function refreshJPVoice() {
    const list = getVoicesSafe();
    jpVoice = list.find(v => /^ja(-JP)?/i.test(v.lang)) || list.find(v => /日本語/.test(v.name)) || null;
  }
  refreshJPVoice();
  try {
    window.speechSynthesis.addEventListener('voiceschanged', () => { refreshJPVoice(); });
  } catch(_) {}

  function voiceById(key) {
    if (!key) return null;
    const list = getVoicesSafe();
    let v = list.find(x => x.voiceURI === key);
    if (v) return v;
    if (key.includes('|')) {
      const [lang, name] = key.split('|');
      v = list.find(x => (x.lang === lang && x.name === name));
      if (v) return v;
    }
    v = list.find(x => x.name === key) || list.find(x => x.lang === key);
    return v || null;
  }

  function chooseVoice(role) {
    const vm = window.__ttsVoiceMap || {};
    const byMap = vm[role];
    if (byMap) {
      if (typeof byMap === 'string') { const v = voiceById(byMap); if (v) return v; }
      else if (typeof byMap === 'object' && byMap) {
        try { if (typeof SpeechSynthesisVoice !== 'undefined' && byMap instanceof SpeechSynthesisVoice) return byMap; } catch(_) {}
        const key = byMap.voiceURI || ((byMap.lang || '') + '|' + (byMap.name || ''));
        const v = voiceById(key);
        if (v) return v;
      }
    }
    try {
      if (window.__ttsUtils && typeof __ttsUtils.pick === 'function') {
        const p = __ttsUtils.pick(role);
        if (p && p.id) {
          const v = voiceById(p.id);
          if (v) return v;
        }
      }
    } catch(_) {}
    return jpVoice || null;
  }

  function clampAbs(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return 1.4;
    return Math.max(0.5, Math.min(2.0, n));
  }

  function effRateFor(role = 'narr', base = 1.4) {
    try {
      if (window.__ttsUtils && typeof __ttsUtils.getRateForRole === 'function') {
        return clampAbs(__ttsUtils.getRateForRole(base, role));
      }
    } catch(_) {}
    return clampAbs(base);
  }
  function rateFor(role = 'narr'){ return effRateFor(role, 1.4); }

  async function primeTTS() {
    if (!TTS_ENABLED || window.ttsPrimed) return;
    await new Promise(resolve => {
      try {
        const u = new SpeechSynthesisUtterance(' ');
        u.lang = 'ja-JP';
        const v = chooseVoice('narr') || jpVoice;
        if (v) u.voice = v;
        u.volume = 0; u.rate = 1.0;
        let doneCalled = false;
        const done = () => { if (!doneCalled) { doneCalled = true; window.ttsPrimed = true; resolve(); } };
        u.onend = done; u.onerror = done;
        speechSynthesis.speak(u);
        setTimeout(done, 800);
      } catch(_) { window.ttsPrimed = true; resolve(); }
    });
  }

  function scrub(text) {
    let s = String(text || '');
    s = s.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, ''); // strip surrogate pairs (emoji etc.)
    s = s.replace(/[:：]/g, '').trim();
    return s;
  }

  function splitChunksJa(s, maxLen = 120) {
    const t = scrub(s);
    if (!t) return [];
    const seps = '。！？?!\n';
    const raw = [];
    let buf = '';
    for (let i = 0; i < t.length; i++) {
      const ch = t[i];
      buf += ch;
      if (seps.indexOf(ch) !== -1) {
        while (i + 1 < t.length && /\s/.test(t[i + 1])) { buf += t[++i]; }
        if (buf.trim()) { raw.push(buf.trim()); buf = ''; }
      }
    }
    if (buf.trim()) raw.push(buf.trim());
    const out = [];
    for (let seg of raw) {
      while (seg.length > maxLen) { out.push(seg.slice(0, maxLen)); seg = seg.slice(maxLen); }
      if (seg) out.push(seg);
    }
    return out;
  }

  function speakStrict(text, rate = rateFor('narr'), role = 'narr') {
    return new Promise(resolve => {
      const cleaned = scrub(text);
      if (!cleaned || !TTS_ENABLED) return resolve();
      let speakText = cleaned;
      for (const k in (speechFixes || {})) { speakText = speakText.split(k).join(speechFixes[k]); }

      const u = new SpeechSynthesisUtterance(speakText);
      u.lang = 'ja-JP';
      const v = chooseVoice(role) || jpVoice;
      if (v) u.voice = v;
      const eff = effRateFor(role, rate);
      u.rate = eff;

      let settled = false;
      const done = () => { if (!settled) { settled = true; resolve(); } };
      u.onend = done; u.onerror = done;

      try { speechSynthesis.speak(u); }
      catch(_) { return done(); }

      const guardMs = Math.min(45000, 800 + (speakText.length * 110) / Math.max(0.5, eff));
      setTimeout(done, guardMs);
    });
  }

  async function speakOrWait(text, rate = rateFor('narr'), role = 'narr') {
    const cleaned = scrub(text);
    if (!cleaned) return;
    const eff = effRateFor(role, rate);
    if (TTS_ENABLED) {
      const parts = splitChunksJa(cleaned);
      for (const p of parts) { await speakStrict(p, eff, role); }
    } else {
      const ms = Math.min(20000, 800 + (cleaned.length * 100) / Math.max(0.5, eff));
      await new Promise(r => setTimeout(r, ms));
    }
  }

  async function runContentSpeech(scene) {
    const flags = (window.__ttsFlags || { readTag: true, readTitleKey: false, readTitle: true, readNarr: true });
    const muted = !TTS_ENABLED;

    if (!muted && flags.readTag && scene.sectionTag) {
      const tagText = String(scene.sectionTag).replace(/^#/, '').replace(/_/g, ' ');
      await speakOrWait(tagText, rateFor('tag'), 'tag');
    }
    if (!muted && flags.readTitleKey && scene.title_key) {
      await speakOrWait(scene.title_key, rateFor('titleKey'), 'titleKey');
    }
    if (!muted && flags.readTitle && scene.title) {
      await speakOrWait(scene.title, rateFor('title'), 'title');
    }
    if (flags.readNarr && scene.narr) {
      await speakOrWait(scene.narr, rateFor('narr'), 'narr');
    }
  }

  /* -----------------------------
   * Renderers (contract DOM)
   * --------------------------- */
  function renderPlaceholder(scene) {
    applyVersionToBody(scene || { uiVersion: 'T' });
    setBg(scene && scene.base || '#000000');
    const root = ensureSceneSurface();

    // Play button (uses .playBtn to match CSS)
    const btn = document.createElement('button');
    btn.className = 'playBtn';
    btn.textContent = '▶︎';
    root.appendChild(btn);

    btn.onclick = async () => {
      btn.disabled = true;
      try { await primeTTS(); } catch(_) {}
      btn.classList.add('hidden');
      await gotoNext();
      try { btn.remove(); } catch(_) {}
    };
  }

  function renderContent(scene) {
    applyVersionToBody(scene);
    setBg(scene.base || '#000000');
    const root = ensureSceneSurface();

    // supply band color variable (JS -> CSS var)
    try { document.body.style.setProperty('--symbol-bg-color', String(scene.base || 'transparent')); } catch(_) {}

    const sc = createSceneShell();

    // Section tag
    if (scene.sectionTag) {
      const tag = document.createElement('div');
      tag.className = 'section-tag';
      tag.textContent = String(scene.sectionTag);
      sc.appendChild(tag);
    }

    // Titles
    if (scene.title_key) {
      const tk = document.createElement('div');
      tk.className = 'title_key';
      tk.textContent = String(scene.title_key || '');
      sc.appendChild(tk);
    }
    if (scene.title) {
      const t = document.createElement('div');
      t.className = 'title';
      t.textContent = String(scene.title || '');
      sc.appendChild(t);
    }

    // Symbol band (optional)
    if (scene.symbol) {
      const band = document.createElement('div');
      band.className = 'symbol-bg';
      const sym = document.createElement('div');
      sym.className = 'symbol';
      sym.textContent = String(scene.symbol || '');
      band.appendChild(sym);
      sc.appendChild(band);
    }

    // Narration
    if (scene.narr) {
      const n = document.createElement('div');
      n.className = 'narr';
      n.textContent = String(scene.narr || '');
      sc.appendChild(n);
    }

    root.appendChild(sc);

    // Adjust readable text color against the base
    applyReadableTextColor(scene.base || '#000000', root);

    // Optional content effect overlay
    runEffectIfAny(scene, root);
  }

  function renderEffect(scene) {
    applyVersionToBody(scene || { uiVersion: 'T' });
    setBg(scene.base || '#000000');
    const root = ensureSceneSurface(); // keep content cleared (pure effect)
    // no text elements (contract)
    runEffectIfAny(scene, root);
  }

  /* -----------------------------
   * Scene type detection
   * --------------------------- */
  function getSceneType(scene) {
    if (!scene) return 'unknown';
    if (typeof scene.type === 'string') return scene.type;
    if (scene.version === 'A' || scene.version === 'B' || scene.version === 'T') return 'content';
    return 'content';
  }

  /* -----------------------------
   * Playback sequencing
   * --------------------------- */
  const State = { scenes: [], idx: 0 };

  async function playScene(scene) {
    if (!scene) return;
    const kind = getSceneType(scene);

    switch (kind) {
      case 'placeholder': {
        renderPlaceholder(scene);
        break;
      }
      case 'content': {
        if (__playingLock) break;
        __playingLock = true;
        try {
          renderContent(scene);
          await primeTTS();
          await runContentSpeech(scene);
        } finally { __playingLock = false; }
        if (typeof gotoNext === 'function') await gotoNext();
        break;
      }
      case 'effect': {
        if (__playingLock) break;
        __playingLock = true;
        try {
          renderEffect(scene);
          const raw = (scene.t !== undefined ? scene.t
                      : (scene.duration !== undefined ? scene.duration
                      : (scene.durationMs !== undefined ? scene.durationMs
                      : (scene.effectDuration !== undefined ? scene.effectDuration : 1200))));
          const effMs = Math.max(0, Math.min(60000, Number(raw) || 1200));
          await new Promise(r => setTimeout(r, effMs));
        } finally { __playingLock = false; }
        if (typeof gotoNext === 'function') await gotoNext();
        break;
      }
      default: {
        if (__playingLock) break;
        __playingLock = true;
        try {
          renderContent(scene);
          await primeTTS();
          await runContentSpeech(scene);
        } finally { __playingLock = false; }
        if (typeof gotoNext === 'function') await gotoNext();
        break;
      }
    }
  }

  async function gotoPage(i) {
    if (!Array.isArray(State.scenes)) return;
    if (i < 0 || i >= State.scenes.length) return;
    State.idx = i;
    const scene = State.scenes[i];
    await playScene(scene);
  }

  async function gotoNext() { await gotoPage(State.idx + 1); }
  async function gotoPrev() { await gotoPage(State.idx - 1); }

  /* -----------------------------
   * Boot
   * --------------------------- */
  async function boot() {
    try {
      const res = await fetch('./scenes.json', { cache: 'no-cache' });
      const data = await res.json();
      const scenes = data.scenes || data || [];
      State.scenes = scenes;
      await gotoPage(0); // Page-1 placeholder
    } catch (e) {
      console.error('Failed to load scenes.json', e);
      ensureSceneSurface();
      setBg('#000');
      const root = document.getElementById('content');
      const sc = createSceneShell();
      setTextInScene(sc, '.title', 'scenes.json の読み込みに失敗しました');
      root.appendChild(sc);
    }
  }

  /* -----------------------------
   * Public API (debug panel minimal bridge)
   * --------------------------- */
  window.__player = window.__player || {
    next: ()=>gotoNext(),
    prev: ()=>gotoPrev(),
    play: ()=>gotoNext(),
    stop: ()=>{}, // NO-OP
    restart: ()=>gotoPage(0),
    goto: (i)=>gotoPage(i|0),
    info: ()=>({ index: State.idx, total: (State.scenes||[]).length, playing: !!__playingLock })
  };
  window.__playerCore = { gotoNext, gotoPrev, gotoPage, rateFor, effRateFor, chooseVoice, primeTTS };

  if (document.readyState === 'complete' || document.readyState === 'interactive') boot();
  else document.addEventListener('DOMContentLoaded', boot, { once: true });
})();