/* =========================================================
   player.core.js — iOS-first refactor (AGI版, bg layering fix)
   ポリシー:
   - Page1=Play専用（placeholder）
   - opening/transition/closing は純エフェクト（本文キー禁止）
   - 読了優先: content は読み終わるまで遷移しない
   - TTS は役割別絶対レート(0.5–2.0)のみ、UIの基準レートなし
   - fetch('./scenes.json') を厳守（inline禁止）
   ========================================================= */
(() => {
  'use strict';

  /* -----------------------------
     環境・既定（既存があれば尊重）
     ----------------------------- */
  const __cfg = (window.__dbgConfig || {});
  const TTS_ENABLED = (typeof window.TTS_ENABLED === 'boolean') ? window.TTS_ENABLED : true;
  const speechFixes = (window.speechFixes || {});
  // デバッグ用TTSフラグの既定（既存あれば尊重）
  window.__ttsFlags = window.__ttsFlags || { readTag: true, readTitleKey: false, readTitle: true, readNarr: true };

  // 再入防止ロック：ページ遷移の多重実行を阻止
  let __playingLock = false;

  /* -----------------------------
     DOM ヘルパ（非破壊フォールバック）
     ----------------------------- */
  const root = document.getElementById('app') || document.body;

  // 背景レイヤ（常に最背面に固定）
  function ensureBgLayer() {
    let bg = document.getElementById('bgColor');
    if (!bg) {
      bg = document.createElement('div');
      bg.id = 'bgColor';
      // bodyの先頭に差し込む（常に背面に置く）
      document.body.insertBefore(bg, document.body.firstChild || null);
    }
    const s = bg.style;
    s.position = 'fixed';
    s.left = '0'; s.top = '0'; s.right = '0'; s.bottom = '0';
    s.zIndex = '0';
    s.pointerEvents = 'none';
    s.transform = 'translateZ(0)'; // 合成レイヤ化でチラツキ抑制
    s.willChange = 'transform';
    return bg;
  }

function setBg(color) {
  try{
    if (!color) return;
    // 1) body 背景
    document.body.style.backgroundColor = color;

    // 2) #bgColor があれば「背面レイヤ」に固定
    const bgEl = document.getElementById('bgColor');
    if (bgEl){
      bgEl.style.backgroundColor = color;
      bgEl.style.position = 'fixed';
      bgEl.style.top = '0';
      bgEl.style.left = '0';
      bgEl.style.right = '0';
      bgEl.style.bottom = '0';
      bgEl.style.zIndex = '0';
      bgEl.style.pointerEvents = 'none';
    }
  }catch(_){}
}

function applyReadableTextColor(base) {
  try {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(base || '').trim());
    if (!m) return;
    const hex = m[1];
    const r = parseInt(hex.slice(0,2),16);
    const g = parseInt(hex.slice(2,4),16);
    const b = parseInt(hex.slice(4,6),16);
    const Y = 0.299*r + 0.587*g + 0.114*b; // 簡易輝度
    const color = (Y < 140) ? '#ffffff' : '#111111';
    const wrap = document.getElementById('spk-wrap');
    if (wrap) wrap.style.color = color;
  } catch(_) {}
}

  function ensureFallbackContainers() {
    // 先に背景レイヤを保証（順序バグを根絶）
    ensureBgLayer();

    // 本文専用のスコープを常に確保（document全体は見ない）
    let wrap = document.getElementById('spk-wrap');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.id = 'spk-wrap';
wrap.style.cssText = 'position:relative;z-index:1000;min-height:100vh;padding:12vw 6vw;box-sizing:border-box;';
      root.appendChild(wrap);
    }
    // 専用ルート内にのみスロットを用意
    ['title_key','title','symbol','narr'].forEach(id => {
      if (!wrap.querySelector('#' + id)) {
        const el = document.createElement(id === 'narr' ? 'p' : 'div');
        el.id = id;
        el.style.cssText = (id === 'narr')
          ? 'white-space:pre-wrap;line-height:1.6;margin-top:1em;'
          : 'font-weight:600;margin:.2em 0;';
        wrap.appendChild(el);
      }
    });
  }

  function setText(id, s) {
    // 本文専用スコープ（spk-wrap）内だけに書く：パネル等への混入を防止
    ensureFallbackContainers();
    const wrap = document.getElementById('spk-wrap');
    const value = s || '';
    const slot = wrap.querySelector('#' + id);
    if (slot) {
      slot.textContent = value;
      if (id === 'narr') slot.style.whiteSpace = 'pre-wrap';
      slot.setAttribute('aria-label', value);
      return;
    }
    const alt = (id === 'title_key') ? 'titleKey' : (id === 'titleKey' ? 'title_key' : null);
    if (alt) {
      const altSlot = wrap.querySelector('#' + alt);
      if (altSlot) {
        altSlot.textContent = value;
        if (alt === 'narr') altSlot.style.whiteSpace = 'pre-wrap';
        altSlot.setAttribute('aria-label', value);
      }
    }
  }

  /* -----------------------------
     状態
     ----------------------------- */
  const State = {
    scenes: [],
    idx: 0,
    voicesReady: false
  };

  /* -----------------------------
     TTS: 音声・速度・発話
     ----------------------------- */

  // 声一覧はiOSで遅延する場合があるため、安全購読
  try {
    window.speechSynthesis.addEventListener('voiceschanged', () => { State.voicesReady = true; refreshJPVoice(); });
  } catch (_) {}

  function getVoicesSafe() {
    try { return window.speechSynthesis.getVoices() || []; }
    catch (_) { return []; }
  }

  function voiceById(key) {
    if (!key) return null;
    const list = getVoicesSafe();
    // 完全一致: voiceURI
    let v = list.find(x => x.voiceURI === key);
    if (v) return v;
    // "lang|name"
    if (key.includes('|')) {
      const [lang, name] = key.split('|');
      v = list.find(x => (x.lang === lang && x.name === name));
      if (v) return v;
    }
    // name一致
    v = list.find(x => x.name === key);
    if (v) return v;
    // lang一致
    v = list.find(x => x.lang === key);
    return v || null;
  }

  let jpVoice = null;
  function refreshJPVoice() {
    const list = getVoicesSafe();
    // 日本語系優先
    jpVoice = list.find(v => /^ja(-JP)?/i.test(v.lang)) || list.find(v => /日本語/.test(v.name)) || null;
  }
  refreshJPVoice();

  // 役割別レート（0.5–2.0）: __ttsUtils.getRateForRole(base, role) を優先
  function effRateFor(role = 'narr', base = (typeof window.rateDefault !== 'undefined' ? window.rateDefault : 1.4)) {
    try {
      if (window.__ttsUtils && typeof __ttsUtils.getRateForRole === 'function') {
        const r = __ttsUtils.getRateForRole(base, role);
        const n = Number(r);
        if (Number.isFinite(n)) return Math.max(0.5, Math.min(2.0, n));
      }
    } catch (_) {}
    const n = Number(base);
    return Math.max(0.5, Math.min(2.0, Number.isFinite(n) ? n : 1.4));
  }
  function rateFor(role = 'narr') { return effRateFor(role); }

  // iOS 初回解錠：無音発話（ユーザー操作内で呼ぶのが確実）
  async function primeTTS() {
    if (!TTS_ENABLED || window.ttsPrimed) return;
    await new Promise(resolve => {
      try {
        const u = new SpeechSynthesisUtterance(' ');
        u.lang = 'ja-JP';
        const v = chooseVoice('narr') || jpVoice;
        if (v) u.voice = v;
        u.volume = 0; u.rate = 1.0;
        let doneCalled = false;
        const done = () => { if (!doneCalled) { doneCalled = true; window.ttsPrimed = true; resolve(); } };
        u.onend = done; u.onerror = done;
        speechSynthesis.speak(u);
        setTimeout(done, 800);
      } catch (_) { window.ttsPrimed = true; resolve(); }
    });
  }

  function chooseVoice(role) {
    const vm = window.__ttsVoiceMap || {};
    const byMap = vm[role];
    if (byMap) {
      if (typeof byMap === 'string') {
        const v = voiceById(byMap);
        if (v) return v;
      } else if (typeof byMap === 'object' && byMap) {
        try { if (typeof SpeechSynthesisVoice !== 'undefined' && byMap instanceof SpeechSynthesisVoice) return byMap; } catch(_) {}
        const key = byMap.voiceURI || ((byMap.lang || '') + '|' + (byMap.name || ''));
        const v = voiceById(key);
        if (v) return v;
      }
    }
    try {
      if (window.__ttsUtils && typeof __ttsUtils.pick === 'function') {
        const p = __ttsUtils.pick(role);
        if (p && p.id) {
          const v = voiceById(p.id);
          if (v) return v;
        }
      }
    } catch (_) {}
    return jpVoice || null;
  }

  function scrub(text) {
    // 後方互換を最優先：サロゲートペア（多くの絵文字）を除去、全角/半角コロンは削除
    let s = String(text || '');
    s = s.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '');
    s = s.replace(/[:：]/g, '').trim();
    return s;
  }

  function splitChunksJa(s, maxLen = 120) {
    const t = scrub(s);
    if (!t) return [];
    // 後読みを使わず手続き的に区切る（Safari互換）
    const seps = '。！？?!\n';
    const raw = [];
    let buf = '';
    for (let i = 0; i < t.length; i++) {
      const ch = t[i];
      buf += ch;
      if (seps.indexOf(ch) !== -1) {
        // 直後の空白群を取り込む
        while (i + 1 < t.length && /\s/.test(t[i + 1])) { buf += t[++i]; }
        if (buf.trim()) { raw.push(buf.trim()); buf = ''; }
      }
    }
    if (buf.trim()) raw.push(buf.trim());
    // 過長分割
    const out = [];
    for (let seg of raw) {
      while (seg.length > maxLen) { out.push(seg.slice(0, maxLen)); seg = seg.slice(maxLen); }
      if (seg) out.push(seg);
    }
    return out;
  }

  function speakStrict(text, rate = rateFor('narr'), role = 'narr') {
    return new Promise(resolve => {
      const cleaned = scrub(text);
      if (!cleaned || !TTS_ENABLED) return resolve();

      let speakText = cleaned;
      for (const k in (speechFixes || {})) { speakText = speakText.split(k).join(speechFixes[k]); }

      const u = new SpeechSynthesisUtterance(speakText);
      u.lang = 'ja-JP';
      const v = chooseVoice(role) || jpVoice;
      if (v) u.voice = v;

      const eff = effRateFor(role, rate);
      u.rate = eff;

      let settled = false;
      const done = () => { if (!settled) { settled = true; resolve(); } };
      u.onend = done; u.onerror = done;

      try { speechSynthesis.speak(u); }
      catch (_) { return done(); }

      // ガード（45s上限）
      const guardMs = Math.min(45000, 800 + (speakText.length * 110) / Math.max(0.5, eff));
      setTimeout(done, guardMs);
    });
  }

  async function speakOrWait(text, rate = rateFor('narr'), role = 'narr') {
    const cleaned = scrub(text);
    if (!cleaned) return;
    const eff = effRateFor(role, rate);

    if (TTS_ENABLED) {
      const parts = splitChunksJa(cleaned);
      for (const p of parts) { await speakStrict(p, eff, role); }
    } else {
      const ms = Math.min(20000, 800 + (cleaned.length * 100) / Math.max(0.5, eff));
      await new Promise(r => setTimeout(r, ms));
    }
  }

  // 役割別TTSの直列再生（読了まで遷移しない）
  async function runContentSpeech(scene) {
    const flags = (window.__ttsFlags || { readTag: true, readTitleKey: false, readTitle: true, readNarr: true });
    const eff = (role, base) => effRateFor(role, base);
    const muted = !TTS_ENABLED;

    // Tag/TitleKey/Title は TTS無効なら待機しない
    if (!muted && flags.readTag && scene.sectionTag) {
      const tagText = String(scene.sectionTag).replace(/^#/, '').replace(/_/g, ' ');
      await speakOrWait(tagText, eff('tag'), 'tag');
    }
    if (!muted && flags.readTitleKey && scene.title_key) {
      await speakOrWait(scene.title_key, eff('titleKey'), 'titleKey');
    }
    if (!muted && flags.readTitle && scene.title) {
      await speakOrWait(scene.title, eff('title'), 'title');
    }
    // Narr は常に読了基準（TTS無効時は読み時間相当で待機）
    if (flags.readNarr && scene.narr) {
      await speakOrWait(scene.narr, eff('narr'), 'narr');
    }
  }

  /* -----------------------------
     レンダリング
     ----------------------------- */
  function renderPlaceholder(scene) {
    setBg(scene.base || '#000000');
    applyReadableTextColor(scene.base || '#000000');
    // 既存UIが無ければ簡易Playを用意
    ensureFallbackContainers();
    const wrap = document.getElementById('spk-wrap');
    let btn = document.getElementById('playBtn');
    if (!btn) {
      btn = document.createElement('button');
      btn.id = 'playBtn';
      btn.textContent = 'Play';
      btn.style.cssText = 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);padding:14px 22px;font-size:18px;z-index:1000;';
      wrap.appendChild(btn);
    }
    btn.onclick = async () => {
      btn.disabled = true;
      try { await primeTTS(); } catch (_) {}
      btn.style.display = 'none';
      await gotoNext();
      try { btn.remove(); } catch (_) {}
    };
    // 本文エリアは空に
    setText('title_key', ''); setText('title', ''); setText('symbol', ''); setText('narr', '');
  }

  function renderContent(scene) {
    ensureFallbackContainers(); // spk-wrap 内にのみ描画
    setBg(scene.base || '#000000');
    applyReadableTextColor(scene.base || '#000000');
    // schemaのキー名（title_key）を基準に専用スコープへ描画
    setText('title_key', scene.title_key || '');
    setText('title', scene.title || '');
    setText('symbol', scene.symbol || '');
    setText('narr', scene.narr || '');
  }

  function renderEffect(scene) {
    setBg(scene.base || '#000000');
    applyReadableTextColor(scene.base || '#000000');
    // 純エフェクトのため本文はクリア
    ensureFallbackContainers();
    setText('titleKey', ''); setText('title', ''); setText('symbol', ''); setText('narr', '');
    // CSSアニメは stylesheet / scene-effects.js に委譲
  }

  /* -----------------------------
     シーン種別の判定（type欠落を救済）
     ----------------------------- */
  function getSceneType(scene) {
    if (!scene) return 'unknown';
    if (typeof scene.type === 'string') return scene.type;
    // version が A/B/T のときは content とみなす（schema準拠）
    if (scene.version === 'A' || scene.version === 'B' || scene.version === 'T') return 'content';
    // 最後の保険：基本は content とみなす
    return 'content';
  }

  /* -----------------------------
     再生シーケンス
     ----------------------------- */
  async function playScene(scene) {
    if (!scene) return;
    const kind = getSceneType(scene);
    switch (kind) {
      case 'placeholder': {
        renderPlaceholder(scene);
        break;
      }
      case 'content': {
        if (__playingLock) break;
        __playingLock = true;
        try {
          renderContent(scene);
          await primeTTS();                 // iOS初回解錠
          await runContentSpeech(scene);    // 読了まで待つ
        } finally {
          __playingLock = false;
        }
        if (typeof gotoNext === 'function') await gotoNext(); // ロック解放後に遷移
        break;
      }
      case 'effect': {
        if (__playingLock) break;
        __playingLock = true;
        try {
          renderEffect(scene);
          // Nullish coalescing（??）非対応環境に配慮して三項で段階解決
          const raw = (scene.t !== undefined ? scene.t
                        : (scene.duration !== undefined ? scene.duration
                        : (scene.durationMs !== undefined ? scene.durationMs
                        : (scene.effectDuration !== undefined ? scene.effectDuration : 1200))));
          const effMs = Math.max(0, Math.min(60000, Number(raw) || 1200)); // 0～60s
          await new Promise(r => setTimeout(r, effMs));
        } finally {
          __playingLock = false;
        }
        if (typeof gotoNext === 'function') await gotoNext(); // ロック解放後に遷移
        break;
      }
      default: {
        // 未知タイプはcontentとして描画（最後の保険）
        if (__playingLock) break;
        __playingLock = true;
        try {
          renderContent(scene);
          await primeTTS();
          await runContentSpeech(scene);
        } finally {
          __playingLock = false;
        }
        if (typeof gotoNext === 'function') await gotoNext();
        break;
      }
    }
  }

  async function gotoPage(i) {
    if (!Array.isArray(State.scenes)) return;
    if (i < 0 || i >= State.scenes.length) return;
    State.idx = i;
    const scene = State.scenes[i];
    await playScene(scene);
  }

  async function gotoNext() { await gotoPage(State.idx + 1); }
  async function gotoPrev() { await gotoPage(State.idx - 1); }

  /* -----------------------------
     起動
     ----------------------------- */
  async function boot() {
    try {
      const res = await fetch('./scenes.json', { cache: 'no-cache' });
      const data = await res.json();
      const scenes = data.scenes || data || [];
      State.scenes = scenes;
      // Page-1 が placeholder である前提（スキーマ準拠）
      await gotoPage(0);
    } catch (e) {
      console.error('Failed to load scenes.json', e);
      ensureFallbackContainers();
      setBg('#000'); // 背景を明示しておく
      setText('title', 'scenes.json の読み込みに失敗しました');
    }
  }

  // （任意）デバッグパネル互換の薄いブリッジ
  window.__player = window.__player || {
    next: ()=>gotoNext(),
    prev: ()=>gotoPrev(),
    play: ()=>gotoNext(),
    stop: ()=>{},             // 現仕様ではNO-OP
    restart: ()=>gotoPage(0),
    goto: (i)=>gotoPage(i|0),
    info: ()=>({ index: State.idx, total: (State.scenes||[]).length, playing: !!__playingLock })
  };

  // 内部APIも必要なら公開
  window.__playerCore = { gotoNext, gotoPrev, gotoPage, rateFor, effRateFor, chooseVoice, primeTTS };

  // 起動
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    boot();
  } else {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  }
})();
